/*
 * locator.h
 *
 *  Created on: Nov 4, 2019
 *      Author: user
 */

#ifndef LOCATOR_H_
#define LOCATOR_H_

float Station_Latitude, Station_Longitude;

float Target_Latitude, Target_Longitude;

float Target_Distance(char target[]);



void set_Station_Coordinates(char station[]);

#endif /* LOCATOR_H_ */
