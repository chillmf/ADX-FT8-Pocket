
#include "si4735.h"
#include "I2C_Master.h"
#define SET_SI4735
#include "arm_math.h"
#include <stdbool.h>
#include "display.h"
#include "button.h"

#include "patch_init.h" // SSB patch for whole SSBRX initialization string


extern int bfo_offset;

int8_t audioMuteMcuPin = -1;
uint8_t refClockSourcePin = 0; //!< 0 = RCLK pin is clock source; 1 = DCLK pin is clock source.
uint16_t refClock = 32768;     //!< Frequency of Reference Clock in Hz.
uint16_t refClockPrescale = 1; //!< Prescaler for Reference Clock (divider).
uint16_t maxDelayAfterPouwerUp = MAX_DELAY_AFTER_POWERUP;      //!< Stores the maximum delay you have to setup after a power up command (in ms).
uint8_t currentClockType = XOSCEN_CRYSTAL; //!< Stores the current clock type used (Crystal or REF CLOCK)
uint8_t currentTune; //!<  tell the current tune (FM, AM or SSB)
uint16_t currentMinimumFrequency; //!<  minimum frequency of the current band
uint16_t currentMaximumFrequency; //!<  maximum frequency of the current band
uint16_t currentWorkFrequency;    //!<  current frequency
uint16_t currentStep; //!<  Stores the current step used to increment or decrement the frequency.

uint8_t this_ctsIntEnable; // Keeps old versions of the sketches running
uint8_t this_gpo2Enable;
uint8_t this_currentAudioMode;
uint8_t this_currentClockType;
uint8_t currentSsbStatus;






size_t size_content = sizeof(ssb_patch_content);
//---------------------------------------------------------------------------------------------
void SI4735_write(uint8_t *data, size_t len)
{
	i2cWrite(data, len, deviceAddress);
}
void SI4735_write_to(uint8_t *data, size_t len, uint16_t to)
{
	i2cWriteTo(data, len, deviceAddress, to);
}
void SI4735_read(uint8_t *data, size_t len)
{
	i2cRead(data, len, deviceAddress);
}
void SI4735_read_from(uint8_t *data, size_t len, uint16_t from)
{
	i2cReadFrom(data, len, deviceAddress, from);
}

void SI4735_setAM(uint16_t fromFreq, uint16_t toFreq, uint16_t initialFreq, uint16_t step)
{

    currentMinimumFrequency = fromFreq;
    currentMaximumFrequency = toFreq;
    currentStep = step;

    if (initialFreq < fromFreq || initialFreq > toFreq)
        initialFreq = fromFreq;

    currentWorkFrequency = initialFreq;
    SI4735_setFrequency(currentWorkFrequency);
}



void general_SI4735_setup(uint8_t resetPin, uint8_t defaultFunction)
{
	SI4735_setup(resetPin, 0, defaultFunction, SI473X_ANALOG_AUDIO, XOSCEN_CRYSTAL,0);
	//SI4735_setup(resetPin, 0, defaultFunction, SI473X_ANALOG_AUDIO, XOSCEN_RCLK,0);

    _delay(250);

   // SI4735_setAM(10000, 20000, 14074, 1);
    SI4735_setVolume(60);
}

/**
 * @brief Starts the Si473X device.
 *
 * @details Use this function to start the device up with the parameters shown below.
 * @details If the audio mode parameter is not entered, analog mode will be considered.
 * @details You can use any Arduino digital pin. Be sure you are using less than 3.6V on Si47XX RST pin.
 *
 * ATTENTION: The document AN383; "Si47XX ANTENNA, SCHEMATIC, LAYOUT, AND DESIGN GUIDELINES"; rev 0.8; page 6; there is the following note:
 *            Crystal and digital audio mode cannot be used at the same time. Populate R1 and remove C10, C11, and X1 when using digital audio.
 *
 * @param resetPin Digital Arduino Pin used to RESET de Si47XX device.
 * @param ctsIntEnable CTS Interrupt Enable.
 * @param defaultFunction is the mode you want the receiver starts.
 * @param audioMode default SI473X_ANALOG_AUDIO (Analog Audio). Use SI473X_ANALOG_AUDIO or SI473X_DIGITAL_AUDIO.
 * @param clockType 0 = Use external RCLK (crystal oscillator disabled); 1 = Use crystal oscillator
 * @param gpo2Enable GPO2OE (GPO2 Output) 1 = Enable; 0 Disable (defult)
 */
void SI4735_setup(uint8_t resetPin, uint8_t ctsIntEnable, uint8_t defaultFunction, uint8_t audioMode, uint8_t clockType, uint8_t gpo2Enable)
{

	this_ctsIntEnable = (ctsIntEnable != 0)? 1:0; // Keeps old versions of the sketches running
	this_gpo2Enable = gpo2Enable;
	this_currentAudioMode = audioMode;
	this_currentClockType = clockType;

    // Set the initial SI473X behavior
    // CTSIEN   interruptEnable -> Interrupt anabled or disable;
    // GPO2OEN  1 -> GPO2 Output Enable;
    // PATCH    0 -> Boot normally;
    // XOSCEN   clockType -> Use external crystal oscillator (XOSCEN_CRYSTAL) or reference clock (XOSCEN_RCLK);
    // FUNC     defaultFunction = 0 = FM Receive; 1 = AM (LW/MW/SW) Receiver.
    // OPMODE   SI473X_ANALOG_AUDIO or SI473X_DIGITAL_AUDIO.
	 SI4735_setPowerUp(ctsIntEnable, gpo2Enable, 0, clockType, defaultFunction, audioMode);



    SI4735_reset();

    SI4735_radioPowerUp();
    SI4735_setVolume(30); // Default volume level.
    SI4735_getFirmware();
}

void SI4735_reset()
{

	SI4735_RST_Set();
	_delay(10);
	SI4735_RST_Clr();
	_delay(10);
	SI4735_RST_Set();
	_delay(10);

}


void SI4735_radioPowerUp(void)
{

	uint8_t content[3];

	content[0] = POWER_UP;
	content[1] = powerUp.raw[0];
	content[2] = powerUp.raw[1];

	SI4735_waitToSend();

	SI4735_write(content, 3);
	if(!devReady(deviceAddress)) {

	};

	SI4735_waitToSend();


    // Turns the external mute circuit off

    if (currentClockType == XOSCEN_RCLK)
    {
    	SI4735_setRefClock(refClock);
    	SI4735_setRefClockPrescaler(1, 0);
    }

}



void SI4735_setRefClockPrescaler(uint16_t prescale, uint8_t rclk_sel)
{
	SI4735_sendProperty(REFCLK_PRESCALE, prescale); //| (rclk_sel << 13)); // Sets the D12 to rclk_sel

}

/**
 * @ingroup group07 Device Power Up parameters
 *
 * @brief Set the Power Up parameters for si473X.
 *
 * @details Use this method to chenge the defaul behavior of the Si473X. Use it before PowerUp()
 * @details About the parameter XOSCEN:
 * @details     0 = Use external RCLK (crystal oscillator disabled);
 * @details     1 = Use crystal oscillator (RCLK and GPO3/DCLK with external 32.768 kHz crystal and OPMODE = 01010000).
 *
 * @see Si47XX PROGRAMMING GUIDE; AN332 (REV 1.0); pages 65 and 129
 *
 * @param uint8_t CTSIEN sets Interrupt anabled or disabled (1 = anabled and 0 = disabled )
 * @param uint8_t GPO2OEN sets GP02 Si473X pin enabled (1 = anabled and 0 = disabled )
 * @param uint8_t PATCH  Used for firmware patch updates. Use it always 0 here.
 * @param uint8_t XOSCEN sets external Crystal enabled or disabled. 0 = Use external RCLK (crystal oscillator disabled); 1 = Use crystal oscillator
 * @param uint8_t FUNC sets the receiver function have to be used [0 = FM Receive; 1 = AM (LW/MW/SW) and SSB (if SSB patch apllied)]
 * @param uint8_t OPMODE set the kind of audio mode you want to use.
 */
void SI4735_setPowerUp(uint8_t CTSIEN, uint8_t GPO2OEN, uint8_t PATCH, uint8_t XOSCEN, uint8_t FUNC, uint8_t OPMODE)
{
    powerUp.arg.CTSIEN = CTSIEN;   // 1 -> Interrupt anabled;
    powerUp.arg.GPO2OEN = GPO2OEN; // 1 -> GPO2 Output Enable;
    powerUp.arg.PATCH = PATCH;     // 0 -> Boot normally;
    powerUp.arg.XOSCEN = XOSCEN;   // 1 -> Use external crystal oscillator;
    powerUp.arg.FUNC = FUNC;       // 0 = FM Receive; 1 = AM/SSB (LW/MW/SW) Receiver.
    powerUp.arg.OPMODE = OPMODE;   // 0x5 = 00000101 = Analog audio outputs (LOUT/ROUT).

    // Set the current tuning frequancy mode 0X20 = FM and 0x40 = AM (LW/MW/SW)
    // See See Si47XX PROGRAMMING GUIDE; AN332 (REV 1.0); pages 55 and 124

   currentClockType = XOSCEN;

    if (FUNC == 0)
    {
        currentTune = FM_TUNE_FREQ;
        currentFrequencyParams.arg.FREEZE = 1;
    }
    else
    {
        currentTune = AM_TUNE_FREQ;
        currentFrequencyParams.arg.FREEZE = 0;
    }
    currentFrequencyParams.arg.FAST = 1;
    currentFrequencyParams.arg.DUMMY1 = 0;
    currentFrequencyParams.arg.ANTCAPH = 0;
    currentFrequencyParams.arg.ANTCAPL = 1;
}


/**
 * @ingroup group13 Audio volume
 *
 * @brief Sets volume level (0  to 63)
 *
 * @see Si47XX PROGRAMMING GUIDE; AN332 (REV 1.0); pages 62, 123, 170, 173 and 204
 *
 * @param uint8_t volume (domain: 0 - 63)
 */
/**
 * @ingroup group13 Audio volume
 *
 * @brief Sets volume level (0  to 63)
 *
 * @see Si47XX PROGRAMMING GUIDE; AN332 (REV 1.0); pages 62, 123, 170, 173 and 204
 *
 * @param uint8_t volume (domain: 0 - 63)
 */
void SI4735_setVolume(uint8_t volume)
{
	SI4735_sendProperty(RX_VOLUME, volume);

}


/**
 * @ingroup group07 Firmware Information
 *
 * @brief Gets firmware information
 * @details The firmware information will be stored in firmwareInfo member variable
 *
 * @see Si47XX PROGRAMMING GUIDE; AN332 (REV 1.0); pages 66, 131
 * @see firmwareInfo
 */
void SI4735_getFirmware(void)
{

	uint8_t content[9];

	content[0] = GET_REV;

	SI4735_waitToSend();
	SI4735_write(content, 1);
	SI4735_waitToSend();

	SI4735_read(content, 9);
	for (int i = 0; i < 9; i++) firmwareInfo.raw[i] = content[i];

	if(!devReady(deviceAddress)) {

	};




}


void SI4735_setRefClock(uint16_t refclk)
{
	SI4735_sendProperty(REFCLK_FREQ, refclk);
   // this->refClock = refclk;
}

/**
 * @ingroup group10 Generic send property
 *
 * @brief Sends (sets) property to the SI47XX
 *
 * @details This method is used for others to send generic properties and params to SI47XX
 *
 * @see Si47XX PROGRAMMING GUIDE; AN332 (REV 1.0); pages 68, 124 and  133.
 * @see setProperty, sendCommand, getProperty, getCommandResponse
 *
 * @param propertyNumber property number (example: RX_VOLUME)
 * @param parameter   property value that will be seted
 */
void SI4735_sendProperty(uint16_t propertyNumber, uint16_t parameter)
{
    si47x_property property;
    si47x_property param;

    property.value = propertyNumber;
    param.value = parameter;

	uint8_t content[6];

	content[0] = SET_PROPERTY;
	content[1] = 0x00;
	content[2] = property.raw.byteHigh;
	content[3] = property.raw.byteLow;
	content[4] = param.raw.byteHigh;
	content[5] = param.raw.byteLow;


	SI4735_waitToSend();

	SI4735_write(content, 6);
	if(!devReady(deviceAddress)) {

	};



}

void SI4735_patchPowerUp(void)
{


	uint8_t content[3];

	content[0] = POWER_UP;
	content[1] = 0b00110001;  //0x31
	content[2] = SI473X_ANALOG_AUDIO;  //0x05

	SI4735_waitToSend();

	SI4735_write(content, 3);
	if(!devReady(deviceAddress)) {

	};

}

void Load_SSB_Patch(void){

	SI4735_setup(0, 0, 1, SI473X_ANALOG_AUDIO, 	XOSCEN_RCLK,0);
	SI4735_queryLibraryId();

	SI4735_patchPowerUp();
	HAL_Delay(50);

	SI4735_downloadPatch(ssb_patch_content, size_content);

	SI4735_setSSBConfig(2, 1, 0, 1, 0, 1);

	SI4735_setSSB(3000, 22000, start_freq, 1, USB);

	SI4735_setSSBBfo(bfo_offset);

	SI4735_setVolume(50);
}

si47x_firmware_query_library SI4735_queryLibraryId(void)
{
    si47x_firmware_query_library libraryID;
    uint8_t content[8];


    SI4735_powerDown(); // Is it necessary


	content[0]  = POWER_UP;
	content[1]  = 0b00011111;
	content[2]  = SI473X_ANALOG_AUDIO;

    SI4735_waitToSend();
	SI4735_write(content, 3);
	if(!devReady(deviceAddress)) {

	};

	SI4735_waitToSend();
	SI4735_read(content, 8);
	for (int i = 0; i < 8; i++) libraryID.raw[i] = content[i];

	if(!devReady(deviceAddress)) {

	};

	HAL_Delay(3);

    return libraryID;
}


void SI4735_powerDown(void)
{
    // Turns the external mute circuit on
	uint8_t content[2];
	content[0]  = POWER_DOWN;

	SI4735_waitToSend();
	SI4735_write(content, 1);
	if(!devReady(deviceAddress)) {

	};

	HAL_Delay(3);

}

bool SI4735_downloadPatch(const uint8_t ssb_patch_content[], const uint16_t ssb_patch_content_size)

{

    uint8_t content[8];
    int offset;//, i = 0;
    int i;
    int tracking_counter = 0;

    // Send patch to the SI4735 device
    for (offset = 0; offset < (int)ssb_patch_content_size; offset += 8) {


    	for (i = 0; i < 8; i++) {
    	content[i] = ssb_patch_content [ i + offset];

    	tracking_counter ++;

    	}
    	SI4735_write(content, 8);

    	SI4735_waitToSend();

    }


    SI4735_waitToSend();


    return true;
}

/**
 * @ingroup group17 Patch and SSB support
 *
 * @brief Sets the SSB receiver mode.
 *
 * @details You can use this method for:
 * @details 1) Enable or disable AFC track to carrier function for receiving normal AM signals;
 * @details 2) Set the audio bandwidth;
 * @details 3) Set the side band cutoff filter;
 * @details 4) Set soft-mute based on RSSI or SNR;
 * @details 5) Enable or disbable automatic volume control (AVC) function.
 *
 * @see AN332 REV 0.8 UNIVERSAL PROGRAMMING GUIDE; page 24
 *
 * @param AUDIOBW SSB Audio bandwidth; 0 = 1.2kHz (default); 1=2.2kHz; 2=3kHz; 3=4kHz; 4=500Hz; 5=1kHz.
 * @param SBCUTFLT SSB side band cutoff filter for band passand low pass filter
 *                 if 0, the band pass filter to cutoff both the unwanted side band and high frequency
 *                  component > 2kHz of the wanted side band (default).
 * @param AVC_DIVIDER set 0 for SSB mode; set 3 for SYNC mode.
 * @param AVCEN SSB Automatic Volume Control (AVC) enable; 0=disable; 1=enable (default).
 * @param SMUTESEL SSB Soft-mute Based on RSSI or SNR.
 * @param DSP_AFCDIS DSP AFC Disable or enable; 0=SYNC MODE, AFC enable; 1=SSB MODE, AFC disable.
 */
void SI4735_setSSBConfig(uint8_t AUDIOBW, uint8_t SBCUTFLT, uint8_t AVC_DIVIDER, uint8_t AVCEN, uint8_t SMUTESEL, uint8_t DSP_AFCDIS)
{
    if (currentTune == FM_TUNE_FREQ) // Only AM/SSB mode
        return;

    currentSSBMode.param.AUDIOBW = AUDIOBW;
    currentSSBMode.param.SBCUTFLT = SBCUTFLT;
    currentSSBMode.param.AVC_DIVIDER = AVC_DIVIDER;
    currentSSBMode.param.AVCEN = AVCEN;
    currentSSBMode.param.SMUTESEL = SMUTESEL;
    currentSSBMode.param.DUMMY1 = 0;
    currentSSBMode.param.DSP_AFCDIS = DSP_AFCDIS;

    SI4735_sendSSBModeProperty();
}


void SI4735_sendSSBModeProperty(void)
{
    si47x_property property;
    property.value = SSB_MODE;

	uint8_t content[6];

	content[0] = SET_PROPERTY;  //0x12
	content[1] = 0x00;
	content[2] = property.raw.byteHigh;
	content[3] = property.raw.byteLow;
	content[4] = currentSSBMode.raw[1];
	content[5] = currentSSBMode.raw[0];


	SI4735_waitToSend();
	SI4735_write(content, 6);
	if(!devReady(deviceAddress)) {

	};

}


/**
 * @ingroup group17 Patch and SSB support
 *
 * @details Tunes the SSB (LSB or USB) receiver to a frequency between 150 and 30 MHz.
 * @details Via VFO you have 1kHz steps.
 * @details Via BFO you have 8Hz steps.
 *
 * @see AN332 REV 0.8 UNIVERSAL PROGRAMMING GUIDE; pages 13 and 14
 * @see setAM()
 * @see setFrequencyStep()
 * @see void SI4735::setFrequency(uint16_t freq)
 *
 * @param fromFreq minimum frequency for the band
 * @param toFreq maximum frequency for the band
 * @param initialFreq initial frequency
 * @param step step used to go to the next channel
 * @param usblsb SSB Upper Side Band (USB) and Lower Side Band (LSB) Selection;
 *               value 2 (banary 10) = USB;
 *               value 1 (banary 01) = LSB.
 */
void SI4735_setSSB(uint16_t fromFreq, uint16_t toFreq, uint16_t initialFreq, uint16_t step, uint8_t usblsb)
{
	currentMinimumFrequency = fromFreq;
    currentMaximumFrequency = toFreq;
    currentStep = step;

    if (initialFreq < fromFreq || initialFreq > toFreq)
        initialFreq = fromFreq;

    setSSB(usblsb);

    currentWorkFrequency = initialFreq;
    SI4735_setFrequency(currentWorkFrequency);
}


/**
 * @ingroup group17 Patch and SSB support
 *
 * @brief Set the radio to AM function.
 *
 * @todo Adjust the power up parameters
 *
 * @details Set the radio to SSB (LW/MW/SW) function.
 *
 * @see AN332 REV 0.8 UNIVERSAL PROGRAMMING GUIDE; pages 13 and 14
 * @see setAM()
 * @see setFrequencyStep()
 * @see void SI4735::setFrequency(uint16_t freq)
 *
 * @param usblsb upper or lower side band;  1 = LSB; 2 = USB
 */
void setSSB(uint8_t usblsb)
{

	SI4735_setPowerUp(this_ctsIntEnable, 0, 0, this_currentClockType, 1, this_currentAudioMode);
	SI4735_radioPowerUp();
	SI4735_setVolume(0x1E); // Set to previous configured volume
    currentSsbStatus = usblsb;

}

void SI4735_setTuneFrequencyAntennaCapacitor(uint16_t capacitor)
{
    si47x_antenna_capacitor cap;

    cap.value = capacitor;

    currentFrequencyParams.arg.DUMMY1 = 0;

    if (currentTune != AM_TUNE_FREQ)
    {
        // For FM, the capacitor value has just one byte
        currentFrequencyParams.arg.ANTCAPH = (capacitor <= 191) ? cap.raw.ANTCAPL : 0;
    }
    else
    {
        if (capacitor <= 6143)
        {
            currentFrequencyParams.arg.FREEZE = 0; // This parameter is not used for AM
            currentFrequencyParams.arg.ANTCAPH = cap.raw.ANTCAPH;
            currentFrequencyParams.arg.ANTCAPL = cap.raw.ANTCAPL;
        }
    }
    // Tune the device again with the current frequency.
    SI4735_setFrequency(currentWorkFrequency);
}


void SI4735_setFrequency(uint16_t freq)
{

	SI4735_waitToSend();
    currentFrequency.value = freq;
    currentFrequencyParams.arg.FREQH = currentFrequency.raw.FREQH;
    currentFrequencyParams.arg.FREQL = currentFrequency.raw.FREQL;

    if (currentSsbStatus != 0)
    {
        currentFrequencyParams.arg.DUMMY1 = 0;
        currentFrequencyParams.arg.USBLSB = currentSsbStatus; // Set to LSB or USB
        currentFrequencyParams.arg.FAST = 1;                  // Used just on AM and FM
        currentFrequencyParams.arg.FREEZE = 0;                // Used just on FM
    }


	uint8_t content[6];

	content[0] = currentTune;
	content[1] = currentFrequencyParams.raw[0];
	content[2] = currentFrequencyParams.arg.FREQH;
	content[3] = currentFrequencyParams.arg.FREQL;
	content[4] = currentFrequencyParams.arg.ANTCAPH;
	content[5] = currentFrequencyParams.arg.ANTCAPL;

	SI4735_write(content, 6);
	if(!devReady(deviceAddress)) {

	};

	SI4735_waitToSend();

}

/**
 * @ingroup group17 Patch and SSB support
 *
 * @brief Sets the SSB Beat Frequency Offset (BFO).
 *
 * @see AN332 REV 0.8 UNIVERSAL PROGRAMMING GUIDE; pages 5 and 23
 *
 * @param offset 16-bit signed value (unit in Hz). The valid range is -16383 to +16383 Hz.
 */
    void  SI4735_setSSBBfo(int offset)
{

    si47x_property property;
    si47x_frequency bfo_offset;

    property.value = SSB_BFO;
    bfo_offset.value = offset;

	uint8_t content[6];

	content[0] = SET_PROPERTY;  //0x12
	content[1] = 0x00;
	content[2] = property.raw.byteHigh;
	content[3] = property.raw.byteLow;
	content[4] = bfo_offset.raw.FREQH;
	content[5] = bfo_offset.raw.FREQL;


	SI4735_waitToSend();
	SI4735_write(content, 6);
	if(!devReady(deviceAddress)) {

	}


}





void SI4735_waitToSend(void)
{
	uint8_t flag[2];

	do
    {
		HAL_Delay(2);
		SI4735_read( flag, 1);
	} while (!(flag[0] & 0B10000000));

}
