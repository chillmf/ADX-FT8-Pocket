

#include "arm_math.h"
#include "I2C_Master.h"
#include "stm32f7xx_hal_i2c.h"
#include <stdbool.h>
#include "display.h"
#include "stm32746g_discovery.h"
#include "stm32f746xx.h"



extern I2C_HandleTypeDef hI2cExtHandler;

I2C_HandleTypeDef *portRADIO = &hI2cExtHandler;

void Si4735_RST_Init(void)
{
    GPIO_InitTypeDef  gpio_init_structure;

    __HAL_RCC_GPIOF_CLK_ENABLE();

    gpio_init_structure.Pin = GPIO_PIN_9;
    gpio_init_structure.Mode = GPIO_MODE_OUTPUT_PP;
    gpio_init_structure.Pull = GPIO_PULLUP;
    gpio_init_structure.Speed = GPIO_SPEED_HIGH;

    HAL_GPIO_Init(GPIOF, &gpio_init_structure);
    HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_SET);  //Set = Receive

     gpio_init_structure.Pin = GPIO_PIN_10;
     gpio_init_structure.Mode = GPIO_MODE_OUTPUT_PP;
     gpio_init_structure.Pull = GPIO_PULLUP;
     gpio_init_structure.Speed = GPIO_SPEED_HIGH;

     HAL_GPIO_Init(GPIOF, &gpio_init_structure);
     HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_SET);  //Set = Receive

}


void SI4735_RST_Clr(void)
	{
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_RESET);
	}

	void SI4735_RST_Set(void)
	{
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_SET);
	}

	uint32_t _millis(void)
	{
		return HAL_GetTick();
	}

	void _delay(uint32_t x)
	{
		HAL_Delay(x);
	}


	void i2cWrite(uint8_t *data, size_t len, uint16_t dev_addr)
	{

		if	(EXT_I2C_MasterWrite(dev_addr <<1, data, len) != HAL_OK) {
			devError |= devI2C;
			cnt_err++;
		} else {

			devError &= ~devI2C;
		}
	}

	void i2cWriteTo(uint8_t *data, size_t len, uint16_t dev_addr, uint16_t to)
	{

		if (EXT_I2C_MemWrite(data, dev_addr <<1,  to,  len) != HAL_OK) {
			devError |= devI2C;
			cnt_err++;
		} else {
			devError &= ~devI2C;
		}
	}

	void i2cRead(uint8_t *data, size_t len, uint16_t dev_addr)
	{

		if	(EXT_I2C_MasterRead (dev_addr << 1, data, len ) != HAL_OK) {

			devError |= devI2C;
			cnt_err++;
		} else {
			devError &= ~devI2C;
		}
	}

	void i2cReadFrom(uint8_t *data, size_t len, uint16_t dev_addr, uint16_t from)
	{
		if (HAL_I2C_Mem_Read(portRADIO , dev_addr << 1, from, 1, data, len, max_wait_ms) != HAL_OK) {
			devError |= devI2C;
			cnt_err++;
		} else {
			devError &= ~devI2C;
		}
	}

	bool devReady(uint16_t dev_addr)
	{

		if ( EXT_I2C_DeviceReady(dev_addr << 1) == HAL_OK)
			return true;
		else
			return false;
	}







