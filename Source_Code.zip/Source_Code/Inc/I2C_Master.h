/*
 * I2C_Master.h
 *
 *  Created on: Oct 9, 2022
 *      Author: Charley
 */

#ifndef I2C_MASTER_H_
#define I2C_MASTER_H_

#include "stm32f7xx_hal.h"
#include "stdbool.h"
#include "arm_math.h"



#define min_wait_ms 150
#define max_wait_ms 1000

	uint16_t lcorX;

	uint8_t devError;
	volatile uint32_t cnt_err;

	typedef struct {
		uint8_t bandType;     // Band type (FM, MW or SW)
		uint16_t minimumFreq; // Minimum frequency of the band
		uint16_t maximumFreq; // maximum frequency of the band
		uint16_t currentFreq; // Default frequency or current frequency
		uint16_t currentStep; // Defeult step (increment and decrement)
	} Band;


	enum {
		devOK = 0,
		devSPI = 1,
		devUART = 2,
		devADC = 4,
		devI2C = 8,
		devFifo = 0x10,
		devMem = 0x20,
		devKBD = 0x40
	};

	void SI4735_RST_Clr();
	void SI4735_RST_Set();
	uint32_t _millis();
	void _delay(uint32_t x);
	void i2cWrite(uint8_t *data, size_t len, uint16_t dev_addr);
	void i2cWriteTo(uint8_t *data, size_t len, uint16_t dev_addr, uint16_t to);
	void i2cRead(uint8_t *data, size_t len, uint16_t dev_addr);
	void i2cReadFrom(uint8_t *data, size_t len, uint16_t dev_addr, uint16_t from);
	bool devReady(uint16_t dev_addr);
	void Si4735_RST_Init(void);
	void Port_Radio_I2C_Init(void);

	extern void SI4735_init(uint8_t defaultFunction);
	void useBand(void);


#endif /* I2C_MASTER_H_ */
