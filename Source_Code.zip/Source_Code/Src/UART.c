/*
 * UART.c
 *
 *  Created on: Nov 11, 2016
 *      Author: charley
 */
/**
  ******************************************************************************
  * @file    UART/UART_TwoBoards_ComIT/Src/main.c
  * @author  MCD Application Team
  * @version V1.0.2
  * @date    18-November-2015
  * @brief   This sample code shows how to use UART HAL API to transmit
  *          and receive a data buffer with a communication process based on
  *          IT transfer.
  *          The communication is done using 2 Boards.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "UART.h"
#include "Display.h"
#include "stm32f7xx_hal.h"
#include "stm32f7xx_hal_uart.h"
#include "main.h"
#include "stm32f7xx_hal_uart.h"
#include "button.h"
UART_HandleTypeDef UartHandle;
__IO ITStatus UartReady = RESET;
__IO uint32_t UserButtonStatus = 0;  /* set to 1 after User Button interrupt  */

extern parse_GPS_sentnce();

uint8_t NEMA_Sentence[gps_buffer];
uint8_t ubx_char[3];
int uart_flag;


void stop_UART(void) {

	HAL_UART_DeInit(&UartHandle);

}


void start_UART(void)  {

  /*##-1- Configure the UART peripheral ######################################*/
  /* Put the USART peripheral in the Asynchronous mode (UART Mode) */
  /* UART configured as follows:
      - Word Length = 8 Bits
      - Stop Bit = One Stop bit
      - Parity = None
      - BaudRate = 9600 baud
      - Hardware flow control disabled (RTS and CTS signals) */
  UartHandle.Instance        = USARTx;
  UartHandle.Init.BaudRate   = 9600;

  UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
  UartHandle.Init.StopBits   = UART_STOPBITS_1;
  UartHandle.Init.Parity     = UART_PARITY_NONE;
  UartHandle.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
  UartHandle.Init.Mode       = UART_MODE_TX_RX;
  UartHandle.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;


  if(HAL_UART_DeInit(&UartHandle) != HAL_OK)
  {
   // Error_Handler();
  }
  if(HAL_UART_Init(&UartHandle) != HAL_OK)
  {
   // Error_Handler();
  }


  HAL_UART_Receive_IT(&UartHandle, (uint8_t *)ubx_char, 1);
  ubx_char[1] = '\n';
  ubx_char[1] = '\0';
}

void sendBuffer(void)  {
	//int i;
	//HAL_UART_Transmit(&UartHandle, (uint8_t*)aTxBuffer, TXBUFFERSIZE, 100);
	//or(i=0;i<TXBUFFERSIZE;i++){
	//	Display_XmitText(aTxBuffer[i]);
	//}

}


void check_rcv_buf(void) {
	if (__HAL_UART_GET_FLAG(&UartHandle, UART_FLAG_RXNE)) receiveBuffer();
}




void receiveBuffer(void) {
	int i;

	if(HAL_UART_Receive(&UartHandle, (uint8_t *)aRxBuffer, gps_buffer, 100) == HAL_OK) {
		BSP_LCD_SetFont (&Font16);
		BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
		BSP_LCD_DisplayStringAt(0, 100, aRxBuffer,0x03);
	}
}



/**
  * @brief  Tx Transfer completed callback
  * @param  UartHandle: UART handle.
  * @note   This example shows a simple way to report end of IT Tx transfer, and
  *         you can add your own implementation.
  * @retval None
  */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *UartHandle)
{
  /* Set transmission flag: transfer complete */
  UartReady = SET;

}

/**
  * @brief  Rx Transfer completed callback
  * @param  UartHandle: UART handle
  * @note   This example shows a simple way to report end of DMA Rx transfer, and
  *         you can add your own implementation.
  * @retval None
  *
  */



/**
  * @brief  UART error callbacks
  * @param  UartHandle: UART handle
  * @note   This example shows a simple way to report transfer error, and you can
  *         add your own implementation.
  * @retval None
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *UartHandle)
{
    Error_Handler();
}


/**
  * @brief EXTI line detection callbacks
  * @param GPIO_Pin: Specifies the pins connected EXTI line
  * @retval None
  */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if(GPIO_Pin == KEY_BUTTON_PIN)
  {
    UserButtonStatus = 1;
  }
}




int start, stop, count;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){



	if(strcmp('$', ubx_char[0]) == 0 ){

		start = 1;
	}


		if(start == 1){

		aRxBuffer[count] = ubx_char[0];
		count++;

			if(strcmp('\n', ubx_char[0]) == 0 ) {

				for (int i = count +1; i < gps_buffer; i++) aRxBuffer[i] = 0;


				if(strncmp(aRxBuffer,"$GPRMC",6  ) == 0 || strncmp(aRxBuffer,"$GPZDA",6  ) == 0 ) {



					if(Tune_On == 1) {

					BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
					BSP_LCD_FillRect(0, 220, 480, 20);
					BSP_LCD_SetFont (&Font16);
					BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
					BSP_LCD_DisplayStringAt(0, 220, aRxBuffer,0x03);
					}

					parse_GPS_sentnce();

				}

					start = 0;
			        count = 0;

				}
			}
		}





void HAL_UART_RxHalfCpltCallback(UART_HandleTypeDef *huart)
{

}







