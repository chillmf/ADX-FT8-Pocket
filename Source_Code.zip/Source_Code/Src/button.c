/*
 * button.c
 *
 *  Created on: Feb 18, 2016
 *      Author: user
 */


#include <stdlib.h>
#include "display.h"
#include "button.h"
#include "stm32746g_discovery_lcd.h"
#include "SDR_Audio.h"
#include "Codec_Gains.h"
#include "decode_ft8.h"
#include "main.h"
#include "stm32fxxx_hal.h"
#include  "Process_DSP.h"
#include "log_file.h"
#include "gen_ft8.h"
#include "traffic_manager.h"
#include "DS3231.h"
#include "SiLabs.h"
#include "si4735.h"
#include "options.h"

extern uint16_t valx,valy;

#define FFT_Resolution 6.25  //8000/2/1280

int AGC_Gain = 25;
int ADC_DVC_Gain = 180;
int HP_Gain = 30;
uint8_t RX_volume = 50;

int freq_scale = 10;

extern uint16_t refClock;
extern void set_RTC_to_GPS(void);

#define numBands 6

FreqStruct sBand_Data[] = {
		{80,
		3573
		},

		{40,
		7074
		},

		{30,
		10136
		},

		{20,
		14074
		},

		{17,
		18100
		},

		{15,
		21074
		}
	};



#define numButtons 19

ButtonStruct sButtonData[] = {


	{	//button 0  inhibit xmit either as beacon or answer CQ
		/*text0*/ "Clr ",
		/*text1*/ "Clr ",
		/*blank*/ "    ",
		/*Active*/ 1,
		/*Displayed*/ 1,
		/*state*/ 0,
		/*x*/ 0,
		/*y*/ line2,
		/*w*/ button_width,
		/*h*/ 30
	},

	{	//button 1 control Beaconing / CQ chasing
		/*text0*/ "QSO ",
		/*text1*/ "Becn",
		/*blank*/ "    ",
		/*Active*/1,
        /*Displayed*/1,
        /*state*/ 0,
		/*x*/ 60,
		/*y*/ line2,
		/*w*/ button_width,
		/*h*/ 30
	},

	{	//button 2 control Tune
		/*text0*/ "Tune",
		/*text1*/ "Tune",
		/*blank*/ "    ",
		/*Active*/ 1,
        /*Displayed*/ 1,
        /*state*/ 0,
		/*x*/ 120,
		/*y*/ line2,
		/*w*/ button_width,
		/*h*/ 30
	},

	{	//button 3 display R/T status
		/*text0*/ "Rcv ",
		/*text1*/ "Xmit",
		/*blank*/ "    ",
		/*Active*/ 1,
        /*Displayed*/ 1,
        /*state*/ 0,
		/*x*/ 180,
		/*y*/ line2,
		/*w*/ 0,  //setting the width and height to 0 turns off touch response , display only
		/*h*/ 0
	},

	{	//button 4 turn on logging
		/*text0*/ "Log ",
		/*text1*/ "Log ",
		/*blank*/  "   ",
		/*Active*/ 1,
        /*Displayed*/ 1,
        /*state*/ 0,
		/*x*/ 240,
		/*y*/ line2,
		/*w*/ button_width,
		/*h*/ 30
	},

	{	//button 5 Sync FT8
		/*text0*/ "Sync",
		/*text1*/ "Sync",
		/*blank*/ "    ",
		/*Active*/ 1,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 300,
		/*y*/ line2,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 6 Lower Gain
		/*text0*/ " G- ",
		/*text1*/ " G- ",
		/*blank*/ "    ",
		/*Active*/ 2,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 360,
		/*y*/ line2,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 7 Raise Gain
		/*text0*/ " G+ ",
		/*text1*/ " G+ ",
		/*blank*/ "    ",
		/*Active*/ 2,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 430,
		/*y*/ line2,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 8 Lower Cursor
		/*text0*/ " F- ",
		/*text1*/ " F- ",
		/*blank*/ "    ",
		/*Active*/ 2,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 320,
		/*y*/ line0,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 9 Raise Cursor
		/*text0*/ " F+ ",
		/*text1*/ " F+ ",
		/*blank*/ "    ",
		/*Active*/ 2,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 420,
		/*y*/ line0,
		/*w*/ button_width,
		/*h*/ 30

	},



	{	//button 10 CLK_Down
		/*text0*/ "CLK-",
		/*text1*/ "CLK-",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 280,
		/*y*/ 120,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 11 CLK_Up
		/*text0*/ "CLK+",
		/*text1*/ "CLK+",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 420,
		/*y*/ 120,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 12 BFO_Down
		/*text0*/ "BFO-",
		/*text1*/ "BFO-",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 280,
		/*y*/ 150,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 13 BFO_Up
		/*text0*/ "BFO+",
		/*text1*/ "BFO+",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 420,
		/*y*/ 150,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 14 Band Down
		/*text0*/ "Band-",
		/*text1*/ "Band-",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 270,
		/*y*/ 40,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 15 Band Up
		/*text0*/ "Band+",
		/*text1*/ "Band+",
		/*blank*/ "     ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 420,
		/*y*/ 40,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 16 Save Calibration Data
		/*text0*/ "Save",
		/*text1*/ "Save",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 360,
		/*y*/ 180,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 17 Xmit for Calibration
		/*text0*/ "Xmit",
		/*text1*/ "Xmit",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 360,
		/*y*/ 100,
		/*w*/ button_width,
		/*h*/ 30

	},

	{	//button 18 Save Calibration Data
		/*text0*/ "Save",
		/*text1*/ "Save",
		/*blank*/ "    ",
		/*Active*/ 0,
        /*Displayed*/ 1,
	    /*state*/ 0,
		/*x*/ 360,
		/*y*/ 70,
		/*w*/ button_width,
		/*h*/ 30

	}


};  // end of button definition





void drawButton(uint16_t i) {

		BSP_LCD_SetFont (&Font16);
	if (sButtonData[i].Active > 0){
        if (sButtonData[i].state == 1)
    	BSP_LCD_SetBackColor(LCD_COLOR_RED);
      else
    	BSP_LCD_SetBackColor(LCD_COLOR_BLUE);

    BSP_LCD_SetTextColor(LCD_COLOR_WHITE);

    if (sButtonData[i].state == 1)
    BSP_LCD_DisplayStringAt(sButtonData[i].x, sButtonData[i].y+15, sButtonData[i].text1, 0x03);
    else
    BSP_LCD_DisplayStringAt(sButtonData[i].x, sButtonData[i].y+15, sButtonData[i].text0, 0x03);

    BSP_LCD_SetBackColor(LCD_COLOR_BLACK);
    }
}



void checkButton(void)  {
      uint16_t i;


    		  for (i=0;i<numButtons;i++){

    		  if (testButton( sButtonData[i].x,sButtonData[i].y,sButtonData[i].w,sButtonData[i].h) == 1)  {

    			  	switch (sButtonData[i].Active){

    				case 0:

    				break;

					case 1:

		    	    sButtonData[i].state =  !sButtonData[i].state;
		    	    drawButton(i);
		    	    executeButton(i);

					break;

					case 2:

		    	    executeButton(i);

					break;

					case 3:
					executeCalibrationButton (i);

					break;

    			  	}


    		  }

      }
}








void executeButton (uint16_t index){

   switch (index) {

   case 0:
	   clear_xmit_messages();
	   terminate_QSO();
	   FT8_Message_Touch = 0;

       sButtonData[0].state = 1;
       drawButton(0);
       HAL_Delay(10);
       sButtonData[0].state = 0;
       drawButton(0);

	   break;

   case 1:
	   if (!sButtonData[1].state)
	  { Beacon_On = 0;
	   Beacon_State = 0;
	   clear_reply_message_box();
	  }
	   else
	  {
	   Beacon_On = 1;
	   clear_reply_message_box();
	   Beacon_State = 1;
       }

       break;

   case 2:
	   if (!sButtonData[2].state)
	   {
	   tune_Off_sequence();
	   Tune_On = 0;
	   Arm_Tune = 0;
  	   xmit_flag = 0;
  	   receive_sequence();
  	   erase_Cal_Display();
	   }
  	   	else
  	   	{
		Tune_On = 1;  //Turns of display of FT8 traffic
		setup_Cal_Display();
		Arm_Tune = 0;
  	   	}
        break;

   case 3:
	   //no code required, all dependent stuff works off of button state
	   break;

   case 4:
   	   if ( sButtonData[4].state == 1 ){
   	   Open_Log_File();
   	   }
   	   else
   	   Close_Log_File();

	   break;

   case 5:
	    FT8_Sync();
		set_RTC_to_GPS();

        sButtonData[5].state = 1;
        drawButton(5);
        HAL_Delay(10);
        sButtonData[5].state = 0;
        drawButton(5);

	   	break;

   case 6:  //Lower Gain
	   if (RX_volume >= 3) RX_volume --;
	   show_short(405, 255, RX_volume );
	   SI4735_setVolume(RX_volume);

	   	break;

   case 7:  //Raise Gain
	   if (RX_volume < 62) RX_volume ++;
	   show_short(405, 255, RX_volume );
	   SI4735_setVolume(RX_volume);

	   	break;

   case 8:  //Lower Freq
	   if (cursor > 0) {
	    cursor --;
	    NCO_Frequency = (double) (cursor+ ft8_min_bin) * FFT_Resolution;
	    }
	    show_variable(370, 20,(int)  NCO_Frequency );

	   	break;

   case 9:  //Raise Freq
	    if (cursor <= (ft8_buffer - ft8_min_bin -2)) {  //limits highest NCO frequency to 3875 hz
	    cursor ++;
	    NCO_Frequency = (double) (cursor+ ft8_min_bin) * FFT_Resolution;
	    }
	    show_variable(370, 20,(int)  NCO_Frequency );

	   	break;

   case 16:  //Save Calibration Changes
	   Clock_Correction = (int) (cal_factor / (int32_t)freq_scale);

	   Options_SetValue(0, Clock_Correction);
	   Options_SetValue(1, bfo_offset);

		Options_StoreValue(0);
		Options_StoreValue(1);

		sButtonData[16].state = 1;
		drawButton(16);
		HAL_Delay(10);
		sButtonData[16].state = 0;
		drawButton(16);

	   break;

   case 17:  //Transmit for Calibration


	   if (!sButtonData[17].state)
	   {

	   tune_Off_sequence();
	   Arm_Tune = 0;
  	   xmit_flag = 0;
  	   receive_sequence();
	   }
  	   	else
  	   	{

  	   	xmit_sequence();
  	   	HAL_Delay(10);
		xmit_flag = 1;
		tune_On_sequence();
		Arm_Tune = 1;
  	   	}

	   break;




   case 18:  //Save Band Changes
	    Options_SetValue(2, BandIndex);
		Options_StoreValue(2);

		start_freq = sBand_Data[BandIndex].Frequency;
		show_wide(350, 0,(int) start_freq );
		SI4735_setSSB(3000, 22000, start_freq, 1, USB);


		sButtonData[18].state = 1;
		drawButton(18);
		HAL_Delay(10);
		sButtonData[18].state = 0;
		drawButton(18);

	   break;
   }

}




   void executeCalibrationButton (uint16_t index){

      switch (index) {
      case 10:  //Lower Cal_Factor

       if(Arm_Tune == 1){
       cal_factor = cal_factor - 1000;
   	   set_correction(cal_factor, SI5351_PLL_INPUT_XO);
   	   output_enable(SI5351_CLK0, 1);
   	   show_wide(340, 140,(int)  cal_factor );
       }

   	   break;

      case 11:  //Raise Cal_Factor

       if(Arm_Tune == 1){
       cal_factor = cal_factor +  1000;
   	   set_correction(cal_factor, SI5351_PLL_INPUT_XO);
   	   output_enable(SI5351_CLK0, 1);
   	   show_wide(340, 140,(int)  cal_factor );
       }

   	   break;

      case 12:  //Lower BFO

       if(Arm_Tune == 1){
   	   bfo_offset = bfo_offset  - 5;
   	   SI4735_setSSBBfo(bfo_offset);
   	   show_variable(340, 170,bfo_offset);
       }

   	   break;

      case 13:  //Raise BFO

       if(Arm_Tune == 1){
   	   bfo_offset = bfo_offset  + 5;
   	   SI4735_setSSBBfo(bfo_offset);
   	   show_variable(340, 170,bfo_offset);
       }

   	   break;

      case 14:  //Lower Band

      if (BandIndex > 0) {
    	  BandIndex --;
    	  show_wide(340, 60, sBand_Data[BandIndex].Frequency );
      }

   	   break;

      case 15:  //Raise Band

	  if (BandIndex < numBands-1) {
		  BandIndex ++;
		  show_wide(340, 60, sBand_Data[BandIndex].Frequency );
	  }

   	   break;


	}

   }

uint16_t testButton(uint16_t x,uint16_t y,uint16_t w,uint16_t h) {

	  y = y +15; // compensate for draw offset

	  if  ((valx < x+w && valx > x) && (valy > y && valy < y+h)){
	  return 1;
	  }else{
	  return 0;
		}
}

uint8_t GetButtonState(uint8_t ibutton)
{
	return sButtonData[ibutton].state;
}


void setup_Cal_Display(void){

	clear_messages();
	clear_xmit_messages();
	for(int i=10; i<16; i++)  sButtonData[i].Active = 3;
	sButtonData[16].Active = 1;
	sButtonData[17].Active = 1;
	sButtonData[18].Active = 1;
	for(int i=10; i<19; i++) drawButton(i);

	show_wide(340, 140, cal_factor );
	show_variable(340, 170, bfo_offset );
	show_wide(340, 60, start_freq );

    BSP_LCD_SetFont (&Font16);
    BSP_LCD_SetTextColor(LCD_COLOR_RED);
    BSP_LCD_DisplayStringAt(80, 85, "Check Filter Board First", LEFT_MODE);
    BSP_LCD_DisplayStringAt(80, 115, "Check Filter Board Again", LEFT_MODE);


}

void erase_Cal_Display(void){
	clear_messages();
	clear_reply_message_box();
	for(int i=10; i<19; i++)  sButtonData[i].Active = 0;
	sButtonData[16].state = 0;
	sButtonData[17].state = 0;
	sButtonData[18].state = 0;
}


void PTT_Out_Init(void)
{
    GPIO_InitTypeDef  gpio_init_structure;


	__HAL_RCC_GPIOI_CLK_ENABLE();


    gpio_init_structure.Pin = GPIO_PIN_2;
    gpio_init_structure.Mode = GPIO_MODE_OUTPUT_OD;
    gpio_init_structure.Pull = GPIO_PULLUP;
    gpio_init_structure.Speed = GPIO_SPEED_HIGH;

    HAL_GPIO_Init(GPIOI, &gpio_init_structure);

    HAL_GPIO_WritePin(GPIOI, GPIO_PIN_2, GPIO_PIN_SET);  //Set = Receive connect

    __HAL_RCC_GPIOA_CLK_ENABLE();


        gpio_init_structure.Pin = GPIO_PIN_15;
        gpio_init_structure.Mode = GPIO_MODE_OUTPUT_OD;
        gpio_init_structure.Pull = GPIO_PULLUP;
        gpio_init_structure.Speed = GPIO_SPEED_HIGH;

        HAL_GPIO_Init(GPIOA, &gpio_init_structure);

        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);  //Set = Receive short

}

void PTT_Out_Set(void)
{
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOI, GPIO_PIN_2, GPIO_PIN_SET);

}

void PTT_Out_RST_Clr(void)
	{

	HAL_GPIO_WritePin(GPIOI, GPIO_PIN_2, GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);

	}


void set_codec_input_gain(void){
	Set_PGA_Gain(AGC_Gain);
	HAL_Delay(10);
	Set_ADC_DVC(ADC_DVC_Gain);
}


void receive_sequence(void) {

	PTT_Out_Set(); // set output high to connect receiver to antenna
	HAL_Delay(10);

	sButtonData[3].state = 0;
	drawButton(3);
}


void xmit_sequence(void)  {

	PTT_Out_RST_Clr();  //set output low to disconnect receiver from antenna

	HAL_Delay(10);

	sButtonData[3].state = 1;
	drawButton(3);

}



void start_Si5351(void){

	  init(SI5351_CRYSTAL_LOAD_8PF, SI5351_XTAL_FREQ, cal_factor);

	  drive_strength(SI5351_CLK0, SI5351_DRIVE_8MA);

	  drive_strength(SI5351_CLK1, SI5351_DRIVE_2MA);

	  drive_strength(SI5351_CLK2, SI5351_DRIVE_2MA);

	  set_freq(refClock *100, SI5351_CLK1);

	  set_freq(refClock *100, SI5351_CLK2);

	  output_enable(SI5351_CLK1, 1);

}



void FT8_Sync(void) {
	start_time = HAL_GetTick();
	ft8_flag = 1;
	FT_8_counter = 0;
	ft8_marker = 1;
	}
