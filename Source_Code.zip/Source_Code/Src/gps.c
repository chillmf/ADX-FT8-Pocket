#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>
#include "UART.h"
#include "Display.h"
#include "stm32746g_discovery_lcd.h"
#include "DS3231.h"

int hex2int(char *c);
int checksum_valid(char *string);
int parse_comma_delimited_str(char *string, char **fields, int max_fields);
int debug_print_fields(int numfields, char **fields);
int OpenGPSPort(const char *devname);
void SetTime(char *date, char *time);

void parse_GPS_sentnce(void);

void parse_GPS_sentnce(void){

	int i;
	char *field[20];

				if (checksum_valid(aRxBuffer)) {
					if ((strncmp(aRxBuffer, "$GP", 3) == 0) |

						(strncmp(aRxBuffer, "$GN", 3) == 0)) {

						if (strncmp(&aRxBuffer[3], "GGA", 3) == 0) {
							i = parse_comma_delimited_str(aRxBuffer, field, 20);
						}

						if (strncmp(&aRxBuffer[3], "RMC", 3) == 0) {
							i = parse_comma_delimited_str(aRxBuffer, field, 20);

							SetTime(field[9],field[1]);
						}

						if (strncmp(&aRxBuffer[3], "ZDA", 3) == 0) {
							i = parse_comma_delimited_str(aRxBuffer, field, 20);

							Set_ZDA_Time(field[2],field[3],field[4],field[1]);

						}


					}
				}
}


int hexchar2int(char c);

int hexchar2int(char c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    return -1;
}


int hex2int(char *c);

int hex2int(char *c)
{
	int value;

	value = hexchar2int(c[0]);
	value = value << 4;
	value += hexchar2int(c[1]);

	return value;
}

int checksum_valid(char *string);

int checksum_valid(char *string)
{
	char *checksum_str;
	int checksum;
	unsigned char calculated_checksum = 0;

	// Checksum is postcede by *
	checksum_str = strchr(string, '*');
	if (checksum_str != NULL){
		// Remove checksum from string
		*checksum_str = '\0';
		// Calculate checksum, starting after $ (i = 1)
		for (int i = 1; i < strlen(string); i++) {
			calculated_checksum = calculated_checksum ^ string[i];
		}
		checksum = hex2int((char *)checksum_str+1);

		if (checksum == calculated_checksum) {

			return 1;
		}
	} else {

		return 0;
	}
	return 0;
}

int parse_comma_delimited_str(char *string, char **fields, int max_fields);

int parse_comma_delimited_str(char *string, char **fields, int max_fields)
{
	int i = 0;
	fields[i++] = string;

	while ((i < max_fields) && NULL != (string = strchr(string, ','))) {
		*string = '\0';
		fields[i++] = ++string;
	}

	return --i;
}


struct tm gpstime;

void SetTime(char *date, char *time);

void SetTime(char *date, char *time)
{
	//struct timespec ts;

	char tempbuf[3];

	// GPS date has format of ddmmyy
	// GPS time has format of hhmmss.ss

	if ((strlen(date) != 6) | (strlen(time) != 9)) {

		return 1;
	}

	// Parse day:
	strncpy(tempbuf, (char *)date, 2);
	tempbuf[2] = '\0';
	gpstime.tm_mday = atoi(tempbuf);

	// Parse month:
	strncpy(tempbuf, (char *)date+2, 2);
	tempbuf[2] = '\0';
	gpstime.tm_mon = atoi(tempbuf);

	// Parse year:
	strncpy(tempbuf, (char *)date+4, 2);
	tempbuf[2] = '\0';
	gpstime.tm_year = atoi(tempbuf);

	// Parse hour:
	strncpy(tempbuf, (char *)time, 2);
	tempbuf[2] = '\0';
	gpstime.tm_hour = atoi(tempbuf);

	// Parse minutes:
	strncpy(tempbuf, (char *)time+2, 2);
	tempbuf[2] = '\0';
	gpstime.tm_min = atoi(tempbuf);

	// Parse seconds:
	strncpy(tempbuf, (char *)time+4, 2);
	tempbuf[2] = '\0';
	gpstime.tm_sec = atoi(tempbuf);

}



void display_UTC_time(void);

void display_UTC_time(void) {

	if(gpstime.tm_hour != 0 && gpstime.tm_min != 0 && gpstime.tm_sec != 0) 	show_UTC_time(0, 240,gpstime.tm_hour,gpstime.tm_min,gpstime.tm_sec, 1);
}


void set_RTC_to_GPS(void);

void set_RTC_to_GPS(void){


	if(gpstime.tm_hour != 0 && gpstime.tm_min != 0 && gpstime.tm_sec != 0 ){
	RTC_setTime(gpstime.tm_hour, gpstime.tm_min, gpstime.tm_sec ,0, 0);
	RTC_setDate(gpstime.tm_mday, gpstime.tm_mday,gpstime.tm_mon, gpstime.tm_year);
	}

}



void Set_ZDA_Time(char *day, char *month, char *year,char *time);

void Set_ZDA_Time(char *day, char *month, char *year,char *time)
{
	struct timespec ts;

	char tempbuf[3];

	// GPS date has format of ddmmyy
	// GPS time has format of hhmmss.ss

	if ((strlen(year) != 4) | (strlen(time) != 9)) {

		return 1;
	}

	// Parse day:
	strncpy(tempbuf, (char *)day, 2);
	tempbuf[2] = '\0';
	gpstime.tm_mday = atoi(tempbuf);

	// Parse month:
	strncpy(tempbuf, (char *)month, 2);
	tempbuf[2] = '\0';
	gpstime.tm_mon = atoi(tempbuf);

	// Parse year:
	strncpy(tempbuf, (char *)year+2, 2);
	tempbuf[2] = '\0';
	gpstime.tm_year = atoi(tempbuf);

	// Parse hour:
	strncpy(tempbuf, (char *)time, 2);
	tempbuf[2] = '\0';
	gpstime.tm_hour = atoi(tempbuf);

	// Parse minutes:
	strncpy(tempbuf, (char *)time+2, 2);
	tempbuf[2] = '\0';
	gpstime.tm_min = atoi(tempbuf);

	// Parse seconds:
	strncpy(tempbuf, (char *)time+4, 2);
	tempbuf[2] = '\0';
	gpstime.tm_sec = atoi(tempbuf);


	ts.tv_sec = mktime(&gpstime);

	ts.tv_nsec = 0;


}
