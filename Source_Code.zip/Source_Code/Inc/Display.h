/*
 * Display.h
 *
 *  Created on: Feb 8, 2016
 *      Author: user
 */

#ifndef DISPLAY_H_
#define DISPLAY_H_
#include	"arm_math.h"


#define FFT_H  40

#define FFT_Resolution 6.25

int FT_8_TouchIndex;
int FT_8_MessageIndex;

uint16_t ft8_scale;

uint16_t cursor;

char ft8_time_string[9];

char rtc_date_string[9];

char rtc_time_string[9];

char date_time_string[25];

int decode_flag;

int display_flag;

int FT8_Touch_Flag;
int FT8_Message_Touch;

void erase_1font( uint16_t x, uint16_t y, uint16_t n);

void show_variable(uint16_t x, uint16_t y,int variable);

void show_text(uint16_t x, uint16_t y,unsigned char text);

void show_decimal(uint16_t x, uint16_t y,float variable);

void show_degrees(uint16_t x, uint16_t y,int32_t variable);

void show_FT8_Parameters(void);

void show_short(uint16_t x, uint16_t y,uint8_t variable);

void show_wide(uint16_t x, uint16_t y,int variable);


void show_FT8_time(uint16_t x, uint16_t y);

void show_UTC_time(uint16_t x, uint16_t y,int utc_hours,int utc_minutes,int utc_seconds, int color);

void show_Real_Date(uint16_t x, uint16_t y,int date,int month,int year);

void show_Date_Time_Group(uint16_t x, uint16_t y);

void make_Date_Time_Group(uint16_t x, uint16_t y,int date,int month,int year,int utc_hours,int utc_minutes,int utc_seconds);


void setup_display(void);

void Display_FFT(void);

void Process_Touch (void);

uint16_t FFT_Touch(void);

int FT8_Touch(void);


void Init_Waterfall (void);

void Display_WF(void);

void Display_ft8_magnitude(void);

void Display_FT8(void);

void Display_FT8_WF(void);

void Set_Cursor_Frequency(uint16_t cursor_pos);

void update_log_display(int mode);

void update_Beacon_log_display(int mode);


#endif /* DISPLAY_H_ */
